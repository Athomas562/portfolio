<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '2w+19gR<q*/;-=C1qnBVDBP*2O=r uY+p&^tcs&a}1z,ntC3e1Ze:.6<E7(^4U9Q' );
define( 'SECURE_AUTH_KEY',   'jcj#c2!s/mar:2jOnx[;Xo{4k[2qbh;`R0,o{>kufj3MHA<IKV(?dXc:_[eTQig.' );
define( 'LOGGED_IN_KEY',     'LwFH9l,lvbKr=;!FzpzQggOnx!A.^h6s/w-5Dv_si@/_&!1f;:]<BxB_r*myNFV1' );
define( 'NONCE_KEY',         'e:J+sccjo^&0n^(#_4u#OB}FnGw@UMrty#clQqM,WtC(k(S*HdZhCvWnF7x|iWf_' );
define( 'AUTH_SALT',         'fR5m49q<2=ZRBo[:M_226P,50ih5EowFt|$d-PN9{YagA]zt3nI3yF`aMa8%N)kP' );
define( 'SECURE_AUTH_SALT',  'UG8{Bub%v`G}VLFJRmg/(rX)B[HV<TBAL8LEwO~!b~(m#;qc!d8S!H?MC!yi+0/y' );
define( 'LOGGED_IN_SALT',    'IT`_Ie(R*I|IVK4~&4LclGyW<E&.$*X-Mt~~_gPUPC<ZQm~K:L<fwR`hoY,o1T^n' );
define( 'NONCE_SALT',        '&d>e3eTnY7gGPEMn<!NWF;aU!/=&B8:je^YNIpSJ7r.OeZM9M$XKl::p+%B9G lk' );
define( 'WP_CACHE_KEY_SALT', '-VFjAreUD+is9WJU[cG][2EIDtI{!yO}TL(PX@$`H $.dNfs.%=]htD[BnFVW$yv' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
